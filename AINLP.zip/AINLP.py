#!/usr/bin/env python
# coding: utf-8

# In[4]:


import torch
from transformers import BertTokenizer, BertForTokenClassification
from torch.utils.data import DataLoader, TensorDataset
import pandas as pd

# Load your training data
train_data = pd.read_csv('sample.csv')  

# Tokenize text and convert labels to numerical format
tokenizer = BertTokenizer.from_pretrained('bert-base-uncased')

tokenized_texts = []
labels = []

# Define label2id mapping
label2id = {'B-Entity': 0, 'I-Entity': 1, 'O': 2}  # Update based on your labels

max_seq_length = 64  # Define the maximum sequence length for padding

for idx, row in train_data.iterrows():
    # Tokenize text
    tokens = tokenizer.encode(row['text'], add_special_tokens=True)
    if len(tokens) > max_seq_length - 2:  # Account for [CLS] and [SEP]
        tokens = tokens[:max_seq_length - 2]
    tokenized_texts.append(tokens)
    
    # Convert labels to numerical format
    label_ids = [label2id[label] for label in row['labels'].split()]
    if len(label_ids) > max_seq_length - 2:  # Account for [CLS] and [SEP]
        label_ids = label_ids[:max_seq_length - 2]
    labels.append(label_ids)

# Padding or truncating tokenized_texts and labels to the same length
tokenized_texts = [tokens + [tokenizer.pad_token_id] * (max_seq_length - len(tokens)) for tokens in tokenized_texts]
labels = [labels + [label2id['O']] * (max_seq_length - len(labels)) for labels in labels]

# Convert tokens and labels to tensors
input_ids = torch.tensor(tokenized_texts)
labels = torch.tensor(labels)

# Create attention masks
attention_masks = (input_ids != tokenizer.pad_token_id).type(torch.long)

# Create TensorDataset and DataLoader
dataset = TensorDataset(input_ids, attention_masks, labels)
train_loader = DataLoader(dataset, batch_size=8, shuffle=True)

# Initialize BERT for token classification (NER)
model = BertForTokenClassification.from_pretrained('bert-base-uncased', num_labels=3)  # Update num_labels

# Define optimizer and training parameters
optimizer = torch.optim.Adam(model.parameters(), lr=1e-5)
num_epochs = 3

# Training loop
for epoch in range(num_epochs):
    model.train()
    for batch in train_loader:
        optimizer.zero_grad()
        input_ids, attention_mask, labels = batch
        outputs = model(input_ids, attention_mask=attention_mask, labels=labels)
        loss = outputs.loss
        loss.backward()
        optimizer.step()
    print(f"Epoch {epoch+1}/{num_epochs} - Loss: {loss.item()}")

# Save the trained model
model.save_pretrained('./trained_model')


# In[1]:


import torch
from transformers import BertTokenizer, BertForTokenClassification
from torch.utils.data import DataLoader, TensorDataset
import pandas as pd
import matplotlib.pyplot as plt

# Load the trained model
model = BertForTokenClassification.from_pretrained('./trained_model')

# Evaluation mode
model.eval()

# Load test data
test_data = pd.read_csv('sample.csv')  # Load your test dataset here

# Tokenize text and convert labels to numerical format
tokenizer = BertTokenizer.from_pretrained('bert-base-uncased')

tokenized_texts_test = []
labels_test = []

# Define label2id mapping
label2id = {'B-Entity': 0, 'I-Entity': 1, 'O': 2}

max_seq_length = 64  # Define the maximum sequence length for padding

for idx, row in test_data.iterrows():
    # Tokenize text
    tokens_test = tokenizer.encode(row['text'], add_special_tokens=True)
    if len(tokens_test) > max_seq_length - 2:  # Account for [CLS] and [SEP]
        tokens_test = tokens_test[:max_seq_length - 2]
    
    tokenized_texts_test.append(tokens_test)
    
    # Convert labels to numerical format (assuming BIO tagging scheme)
    label_ids_test = [label2id[label] for label in row['labels'].split()]
    if len(label_ids_test) > max_seq_length - 2:  # Account for [CLS] and [SEP]
        label_ids_test = label_ids_test[:max_seq_length - 2]
    
    labels_test.append(label_ids_test)

# Padding or truncating tokenized_texts_test and labels_test to the same length
tokenized_texts_test = [tokens_test + [tokenizer.pad_token_id] * (max_seq_length - len(tokens_test)) for tokens_test in tokenized_texts_test]
labels_test = [labels_test + [label2id['O']] * (max_seq_length - len(labels_test)) for labels_test in labels_test]

# Convert tokens and labels to tensors
test_input_ids = torch.tensor(tokenized_texts_test)
test_labels = torch.tensor(labels_test)

# Create attention masks
attention_masks = (test_input_ids != tokenizer.pad_token_id).type(torch.long)

# Create DataLoader for test data with batch size 1
test_dataset = TensorDataset(test_input_ids, attention_masks, test_labels)
test_loader = DataLoader(test_dataset, batch_size=1, shuffle=False)

# Evaluation loop
accuracies = []

for batch_idx, batch in enumerate(test_loader):
    with torch.no_grad():
        input_ids, attention_mask, labels = batch
        outputs = model(input_ids, attention_mask=attention_mask, labels=labels)
        logits = outputs.logits
        predicted_labels = torch.argmax(logits, dim=2)
        
        # Calculate accuracy (excluding padded tokens)
        mask = (input_ids != tokenizer.pad_token_id)
        correct = ((predicted_labels == labels) * mask).sum().item()
        accuracy = correct / mask.sum().item()
        accuracies.append(accuracy)

        print(f"Batch {batch_idx + 1}: Accuracy: {accuracy}")

# Save accuracies to a CSV file
pd.DataFrame(accuracies, columns=['Accuracy']).to_csv('accuracies.csv', index=False)
print("Accuracies saved to 'accuracies.csv'")


# In[3]:


import torch
from transformers import BertTokenizer, BertForTokenClassification

# Load pre-trained BERT model and tokenizer
model = BertForTokenClassification.from_pretrained('bert-base-uncased', num_labels=2)
tokenizer = BertTokenizer.from_pretrained('bert-base-uncased')

# Example sentence
text = "Apple is a company based in California"

# Tokenize the input text
tokens = tokenizer.tokenize(text)
tokens_ids = tokenizer.convert_tokens_to_ids(tokens)
input_ids = torch.tensor([tokens_ids])

# Obtain predictions
with torch.no_grad():
    outputs = model(input_ids)

# Get the predicted labels
predicted_labels = torch.argmax(outputs.logits, dim=2)

# Decode the predicted labels
predicted_tags = [tokenizer.decode(i) for i in predicted_labels[0].tolist()]

# Output the tokens with their predicted tags
for token, tag in zip(tokens, predicted_tags):
    print(f"{token}: {tag}")


# In[ ]:




